create definer = root@localhost view view_testler as
select `qbdb`.`testler`.`id`            AS `id`,
       `qbdb`.`kullanicilar`.`username` AS `Kullanici`,
       `qbdb`.`konular`.`baslik`        AS `Konu`,
       `qbdb`.`testler`.`soru`          AS `Soru`,
       `qbdb`.`testler`.`derece`        AS `Derece`,
       `qbdb`.`testler`.`tarih`         AS `Tarih`,
       `qbdb`.`testler`.`type`          AS `Tip`,
       `qbdb`.`testler`.`status`        AS `Durum`
from ((`qbdb`.`testler` join `qbdb`.`konular` on ((`qbdb`.`testler`.`konu_id` = `qbdb`.`konular`.`id`)))
       join `qbdb`.`kullanicilar` on ((`qbdb`.`testler`.`kullanici_id` = `qbdb`.`kullanicilar`.`id`)));

